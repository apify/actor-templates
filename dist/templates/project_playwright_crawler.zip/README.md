# PlaywrightCrawler project

This template is a production ready boilerplate for developing with `PlaywrightCrawler`.
Use this to bootstrap your projects using the most up-to-date code.

If you're looking for examples or want to learn more visit:
- [Documentation](https://sdk.apify.com/docs/api/playwright-crawler)
- [Examples](https://sdk.apify.com/docs/examples/playwright-crawler)

## Documentation reference

- [Apify SDK](https://sdk.apify.com/)
- [Apify Actor documentation](https://docs.apify.com/actor)
- [Apify CLI](https://docs.apify.com/cli)
