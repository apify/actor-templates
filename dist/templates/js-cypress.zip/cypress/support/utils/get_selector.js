
// ES2015 module export function
// which simply concats a class selector
// to the string argument

export default (str) => {
    return `.my-app-${str}`
  }
  