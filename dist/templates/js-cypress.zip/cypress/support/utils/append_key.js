module.exports = function (str) {
    return `${str}+APIkey123`
  }