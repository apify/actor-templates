export const PPE_EVENT = {
    ACTOR_START_GB: 'actor-start-gb',
    OPENAI_100_TOKENS_GPT_4O: 'openai-100-tokens-gpt-4o',
    OPENAI_100_TOKENS_GPT_4O_MINI: 'openai-100-tokens-gpt-4o-mini',
} as const;
