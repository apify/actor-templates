# Python starter Actor template

The `README.md` file documents what your actor does and how to use it, which is then displayed in the Console or Apify Store. It's always a good idea to write a `README.md`. In a few months, not even you will remember all the details about the actor.

You can use [Markdown](https://www.markdownguide.org/cheat-sheet) language for rich formatting.
