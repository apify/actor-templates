# Bootstrap CheerioCrawler

This is a project skeleton to help you bootstrap `CheerioCrawler` projects in TypeScript faster. It will always use the most up-to-date configuration and include all the common files. It's made for developers already familiar with Apify SDK and Crawlee and doesn't include any guidance.

If you're looking for examples or want to learn how to use Apify, Apify SDK or Crawlee, see the other templates.
