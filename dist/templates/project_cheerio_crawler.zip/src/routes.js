const { log } = require('crawlee');

exports.handleStart = async ({ request, $ }) => {
    // Handle Start URLs
};

exports.handleList = async ({ request, $ }) => {
    // Handle pagination
};

exports.handleDetail = async ({ request, $ }) => {
    // Handle details
};
