const Apify = require('apify');

const { utils: { log } } = Apify;

exports.handleStart = async ({ request, $ }) => {
    // Handle Start URLs
};

exports.handleList = async ({ request, $ }) => {
    // Handle pagination
};

exports.handleDetail = async ({ request, $ }) => {
    // Handle details
};
