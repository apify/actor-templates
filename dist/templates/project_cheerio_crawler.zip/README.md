# CheerioCrawler project

This template is a production ready boilerplate for developing with `CheerioCrawler`.
Use this to bootstrap your projects using the most up-to-date code.

If you're looking for examples or want to learn more visit:
- [Tutorial](https://sdk.apify.com/docs/guides/getting-started#cheeriocrawler-aka-jquery-crawler) 
- [Documentation](https://sdk.apify.com/docs/api/cheerio-crawler) 
- [Examples](https://sdk.apify.com/docs/examples/cheerio-crawler) 

## Documentation reference

- [Apify SDK](https://sdk.apify.com/)
- [Apify Actor documentation](https://docs.apify.com/actor)
- [Apify CLI](https://docs.apify.com/cli)
