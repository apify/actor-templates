import asyncio

from .main import main

asyncio.run(main())
