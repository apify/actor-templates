# This package will contain the spiders of your Scrapy project
#
# Please refer to the Scrapy documentation for information on how to create and manage your spiders.
#
# https://docs.scrapy.org/en/latest/topics/spiders.html
