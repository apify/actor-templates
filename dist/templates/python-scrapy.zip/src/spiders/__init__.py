"""
Scrapy spiders package

This package contains the spiders for your Scrapy project. Spiders are the classes that define how to scrape
and process data from websites.

For detailed information on creating and utilizing spiders, refer to the official documentation:
https://docs.scrapy.org/en/latest/topics/spiders.html
"""
