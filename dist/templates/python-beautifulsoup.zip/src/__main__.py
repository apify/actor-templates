import asyncio

from .main import main

# Execute the Actor entrypoint.
asyncio.run(main())
